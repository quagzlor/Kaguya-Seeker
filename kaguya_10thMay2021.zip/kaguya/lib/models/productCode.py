from lib.db import db

class ProductCode(db.Model):
    __tablename__ ="product_code"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    pcode = db.Column(db.String(64), nullable=False)
    feature = db.relationship('Feature', backref='feature', uselist=False)
    pcode = db.relationship('Catalog', backref='pcode', uselist=False)


    def __init__(self, name, pcode):
        self.name = name
        self.pcode = pcode