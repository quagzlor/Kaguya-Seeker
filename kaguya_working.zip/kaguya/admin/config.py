DEBUG = True
ADMIN_USER_ID= 'test'
ADMIN_PASSWORD = 'password'
