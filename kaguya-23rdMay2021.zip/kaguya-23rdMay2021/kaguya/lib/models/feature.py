from lib.db import db

class Feature(db.Model):
    __tablename__ ="features"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    latitude = db.Column(db.Integer, nullable=False)
    longitude = db.Column(db.Integer, nullable=False)
    starting_latitude = db.Column(db.Integer, nullable=False)
    ending_latitude = db.Column(db.Integer, nullable=False)
    starting_longitude = db.Column(db.Integer, nullable=False)
    ending_longitude = db.Column(db.Integer, nullable=False)
    # direction_id = db.Column(db.Integer, db.ForeignKey('direction.id'))
    diameter = db.Column(db.Integer, nullable=False)
    ethnicitys_id = db.Column(db.Integer, db.ForeignKey('ethnicitys.id'), nullable=False)
    # quad_id = db.Column(db.Integer, db.ForeignKey('quad.id'))
    # map_id = db.Column(db.Integer, db.ForeignKey('map.id'))
    # approval_status_id = db.Column(db.Integer, db.ForeignKey('approval_status.id'))
    approval_date = db.Column(db.DateTime, nullable=False)
    ref = db.Column(db.Integer, nullable=False)
    reference_text = db.Column(db.String(64), nullable=False)
    feature_types_id = db.Column(db.Integer, db.ForeignKey('feature_types.id'), nullable=False)
    origin = db.Column(db.String(64), nullable=False)
    #location = db.Column(db.Float(64), nullable=False)
    circle_area = db.Column(db.Float, nullable=False)
    square_area = db.Column(db.Float, nullable=False)
    circle_area_mod = db.Column(db.Float, nullable=False)

    def __init__(self, name, latitude, longitude, starting_latitude, ending_latitude, starting_longitude, ending_longitude, diameter, ethnicitys_id, approval_date, ref, reference_text, feature_types_id, origin, circle_area, square_area, circle_area_mod):
        name = name
        latitude = latitude
        longitude = longitude
        starting_latitude = starting_latitude
        ending_latitude = ending_latitude
        starting_longitude = starting_longitude
        ending_longitude = ending_longitude
        # direction_id = direction_id
        diameter = diameter
        ethnicitys_id = ethnicitys_id
        # quad_id = quad_id
        # map_id = map_id
        # approval_status_id = approval_status_id
        approval_date = approval_date
        ref = ref
        reference_text = reference_text
        feature_types_id = feature_types_id
        origin = origin
        #location = location
        circle_area = circle_area
        square_area = square_area
        circle_area_mod = circle_area_mod

